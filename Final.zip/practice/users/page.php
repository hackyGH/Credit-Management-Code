<!DOCTYPE html>
<html>
<head>
	<title>Homepage(Credit Management)</title>
</head>
<body>
	<?php
	<h4>Welcome To Credit Managemt System</h4>
	<button type="button">All User</button>
	?>
</body>
</html>