</div>
<div class="container">
    <div class="col-xs-2 col-xs-offset-5">
      <br/><br/>
      <a href="../index.php" class="btn btn-primary ">Go Back To Home</a>
      <br/><br/><br/>
    </div>
</div>
</body>
</html>
